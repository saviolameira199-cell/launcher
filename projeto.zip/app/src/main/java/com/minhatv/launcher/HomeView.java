package com.minhatv.launcher;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Tela inicial desenhada em Canvas num espaço virtual de 1920x1080. Sem blur, sem rede, sem vídeo. */
public class HomeView extends View {
  static final float W = 1920, H = 1080;
  static final int TW = 380, TH = 214, GAP = 40, X0 = 140, DOCK_Y = 588, GRID_Y = 910, PITCH = 290;
  static final String DEF_DOCK = "com.global.unitviptv,com.spotify.tv.android,com.google.android.youtube.tv,com.netflix.ninja";
  static final Set<String> BLACK = new HashSet<>(Arrays.asList("com.minhatv.launcher", "com.android.tv.settings",
      "com.mediatek.androidbox", "com.expressluck.tvhelpmanual", "com.mediatek.wwtv.tvcenter"));
  static final int DEF_GLOW = 0xFF4A5AD8;

  static class App { String pkg, cls, label; ResolveInfo ri; volatile Bitmap bmp; volatile int color; }
  static class Inp { String label; Intent intent; }

  final Context ctx; final PackageManager pm; final SharedPreferences sp;
  final List<App> dock = new ArrayList<>(), grid = new ArrayList<>();
  final HashMap<String, App> cache = new HashMap<>();
  final List<Inp> inputs = new ArrayList<>();
  int zone = 1, topIdx = 1, dockIdx = 0, gridIdx = 0, ddIdx = 0, bg = 0xFF0B0B12;
  boolean ddOpen, restored; long wallStamp = -1; Bitmap wall; String wifi = "Wi-Fi";

  // animação
  float p = 1; final ValueAnimator anim = ValueAnimator.ofFloat(0, 1);
  final RectF hFrom = new RectF(), hTo = new RectF(), full = new RectF(0, 0, W, H);
  float scFrom, scTo, hlFrom = 1, hlTo = 1; int glFrom = DEF_GLOW, glTo = DEF_GLOW, selPrev = -1;
  final ArgbEvaluator ev = new ArgbEvaluator();

  final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG), pFill = new Paint(Paint.ANTI_ALIAS_FLAG),
      pStroke = new Paint(Paint.ANTI_ALIAS_FLAG), pBmp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG),
      pGlow = new Paint();
  Typeface tfThin, tfReg, tfMed;
  final RectF[] pills = {new RectF(), new RectF(), new RectF()};
  final Runnable ticker = new Runnable() { public void run() { updateWifi(); invalidate(); postDelayed(this, 20000); } };

  public HomeView(Context c) {
    super(c); ctx = c; pm = c.getPackageManager(); sp = c.getSharedPreferences("cfg", 0);
    tfThin = font(200, "sans-serif-thin"); tfReg = font(400, "sans-serif"); tfMed = font(500, "sans-serif-medium");
    pStroke.setStyle(Paint.Style.STROKE); pStroke.setStrokeWidth(3);
    anim.setDuration(170); anim.setInterpolator(new DecelerateInterpolator());
    anim.addUpdateListener(a -> { p = (float) a.getAnimatedValue(); invalidate(); });
    setFocusable(true);
  }

  Typeface font(int w, String fb) {
    try {
      if (Build.VERSION.SDK_INT >= 26) {
        Typeface t = new Typeface.Builder(ctx.getAssets(), "Outfit.ttf").setFontVariationSettings("'wght' " + w).build();
        if (t != null) return t;
      }
    } catch (Exception e) { }
    return Typeface.create(fb, Typeface.NORMAL);
  }

  @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); post(ticker); }
  @Override protected void onDetachedFromWindow() { super.onDetachedFromWindow(); removeCallbacks(ticker); }

  // ---------- dados ----------
  void reload() {
    try { bg = Color.parseColor(sp.getString("bg", "#0B0B12")); } catch (Exception e) { bg = 0xFF0B0B12; }
    File wf = new File(String.valueOf(ctx.getExternalFilesDir(null)), "wallpaper.jpg");
    if (wf.exists()) {
      if (wallStamp != wf.lastModified()) {
        wallStamp = wf.lastModified();
        try {
          BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
          BitmapFactory.decodeFile(wf.getPath(), o);
          int s = 1; while (o.outWidth / s > 2000) s *= 2;
          o = new BitmapFactory.Options(); o.inSampleSize = s; o.inPreferredConfig = Bitmap.Config.RGB_565;
          wall = BitmapFactory.decodeFile(wf.getPath(), o);
        } catch (Throwable t) { wall = null; }
      }
    } else { wall = null; wallStamp = -1; }

    Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
    LinkedHashMap<String, App> by = new LinkedHashMap<>();
    for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
      String pkg = ri.activityInfo.packageName;
      if (by.containsKey(pkg)) continue;
      App a = cache.get(pkg);
      if (a == null) {
        a = new App(); a.pkg = pkg; a.cls = ri.activityInfo.name; a.ri = ri; a.label = String.valueOf(ri.loadLabel(pm));
        cache.put(pkg, a);
      }
      by.put(pkg, a);
    }
    dock.clear(); grid.clear();
    Set<String> used = new HashSet<>();
    for (String s : sp.getString("dock", DEF_DOCK).split(",")) {
      s = s.trim(); App a = by.get(s);
      if (a != null && dock.size() < 4 && used.add(s)) dock.add(a);
    }
    for (App a : by.values()) if (!used.contains(a.pkg) && !BLACK.contains(a.pkg)) grid.add(a);
    Collections.sort(grid, (x, y) -> x.label.compareToIgnoreCase(y.label));

    if (!restored) {
      restored = true; zone = sp.getInt("zone", 1); dockIdx = sp.getInt("dockIdx", 0); gridIdx = sp.getInt("gridIdx", 0);
    }
    dockIdx = Math.min(dockIdx, Math.max(0, dock.size() - 1));
    gridIdx = Math.min(gridIdx, Math.max(0, grid.size() - 1));
    if (zone == 0) zone = 1;
    if (zone == 1 && dock.isEmpty()) zone = grid.isEmpty() ? 0 : 2;
    if (zone == 2 && grid.isEmpty()) zone = dock.isEmpty() ? 0 : 1;
    updateWifi(); jump();

    final List<App> todo = new ArrayList<>();
    for (App a : dock) if (a.bmp == null) todo.add(a);
    for (App a : grid) if (a.bmp == null) todo.add(a);
    if (todo.isEmpty()) return;
    new Thread(() -> {
      for (App a : todo) {
        try {
          Drawable d = a.ri.activityInfo.loadBanner(pm); boolean banner = d != null;
          if (d == null) d = a.ri.activityInfo.loadIcon(pm);
          Bitmap b = tile(d, banner); a.color = dominant(b); a.bmp = b;
        } catch (Throwable t) { }
        postInvalidate();
      }
      post(() -> { if (p >= 1) jump(); });
    }).start();
  }

  Bitmap tile(Drawable d, boolean banner) {
    Bitmap out = Bitmap.createBitmap(TW, TH, Bitmap.Config.ARGB_8888);
    Canvas c = new Canvas(out);
    Path clip = new Path(); clip.addRoundRect(0, 0, TW, TH, 22, 22, Path.Direction.CW); c.clipPath(clip);
    if (banner) {
      int iw = d.getIntrinsicWidth(), ih = d.getIntrinsicHeight();
      if (iw <= 0 || ih <= 0) { iw = 320; ih = 180; }
      float s = Math.max((float) TW / iw, (float) TH / ih); int w = (int) (iw * s), h = (int) (ih * s);
      d.setBounds((TW - w) / 2, (TH - h) / 2, (TW + w) / 2, (TH + h) / 2);
    } else {
      c.drawColor(0xFF22252E); d.setBounds((TW - 130) / 2, (TH - 130) / 2, (TW + 130) / 2, (TH + 130) / 2);
    }
    d.draw(c);
    return out;
  }

  static int dominant(Bitmap b) {
    Bitmap s = Bitmap.createScaledBitmap(b, 16, 9, true);
    float r = 0, g = 0, bl = 0, w = 0; float[] hsv = new float[3];
    for (int y = 0; y < 9; y++) for (int x = 0; x < 16; x++) {
      int px = s.getPixel(x, y); if (Color.alpha(px) < 200) continue;
      Color.colorToHSV(px, hsv); if (hsv[1] < 0.35f || hsv[2] < 0.25f) continue;
      float k = hsv[1] * hsv[2]; r += Color.red(px) * k; g += Color.green(px) * k; bl += Color.blue(px) * k; w += k;
    }
    return w == 0 ? DEF_GLOW : Color.rgb((int) (r / w), (int) (g / w), (int) (bl / w));
  }

  void updateWifi() {
    String r = "Sem rede";
    try {
      ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
      Network n = cm.getActiveNetwork(); NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
      if (nc != null) {
        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
          r = "Wi-Fi";
          WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
          String s = wm.getConnectionInfo().getSSID();
          if (s != null && !s.contains("unknown")) r = s.replace("\"", "");
        } else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) r = "Ethernet";
        else r = "Conectado";
      }
    } catch (Exception e) { }
    wifi = r;
  }

  void loadInputs() {
    inputs.clear();
    Inp t = new Inp(); t.label = "TV ao vivo";
    t.intent = new Intent().setClassName("com.mediatek.wwtv.tvcenter", "com.mediatek.wwtv.tvcenter.nav.TurnkeyUiMainActivity");
    inputs.add(t);
    try {
      TvInputManager tm = (TvInputManager) ctx.getSystemService(Context.TV_INPUT_SERVICE);
      for (TvInputInfo ti : tm.getTvInputList()) {
        if (!ti.isPassthroughInput() || ti.isHidden(ctx)) continue;
        Inp i = new Inp(); i.label = String.valueOf(ti.loadLabel(ctx));
        i.intent = new Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(ti.getId()));
        inputs.add(i);
      }
    } catch (Exception e) { }
  }

  // ---------- geometria / estado ----------
  RectF dockRect(int i) { float x = X0 + i * (TW + GAP); return new RectF(x, DOCK_Y, x + TW, DOCK_Y + TH); }
  RectF gridRect(int i) { float x = X0 + (i % 4) * (TW + GAP), y = GRID_Y + (i / 4) * PITCH; return new RectF(x, y, x + TW, y + TH); }
  RectF target() { return zone == 2 && !grid.isEmpty() ? gridRect(gridIdx) : dockRect(dockIdx); }
  int key() { return zone == 1 ? 100 + dockIdx : zone == 2 ? 200 + gridIdx : -1; }
  App cur() { return zone == 2 && !grid.isEmpty() ? grid.get(gridIdx) : (dock.isEmpty() ? null : dock.get(dockIdx)); }
  int glowFor() { App a = cur(); return a != null && a.color != 0 ? a.color : DEF_GLOW; }
  float scrollFor() {
    if (zone != 2 || grid.isEmpty()) return 0;
    int last = (grid.size() - 1) / 4;
    float max = Math.max(0, GRID_Y + last * PITCH + TH + 60 + 30 - H);
    return Math.min(GRID_Y + (gridIdx / 4) * PITCH - 280, max);
  }
  static float lerp(float a, float b, float t) { return a + (b - a) * t; }
  float curScroll() { return lerp(scFrom, scTo, p); }
  float curHl() { return lerp(hlFrom, hlTo, p); }
  int curGlow() { return (Integer) ev.evaluate(p, glFrom, glTo); }
  RectF curRect() { return new RectF(lerp(hFrom.left, hTo.left, p), lerp(hFrom.top, hTo.top, p), lerp(hFrom.right, hTo.right, p), lerp(hFrom.bottom, hTo.bottom, p)); }

  void jump() {
    anim.cancel(); hTo.set(target()); hFrom.set(hTo); scFrom = scTo = scrollFor(); glFrom = glTo = glowFor();
    hlFrom = hlTo = zone == 0 ? 0 : 1; selPrev = key(); p = 1; invalidate();
  }

  void commit(int old) {
    RectF c = curRect(); float cs = curScroll(), ch = curHl(); int cg = curGlow();
    anim.cancel(); hFrom.set(c); hTo.set(target()); scFrom = cs; scTo = scrollFor(); glFrom = cg; glTo = glowFor();
    hlFrom = ch; hlTo = zone == 0 ? 0 : 1; selPrev = old; p = 0; anim.start();
    sp.edit().putInt("zone", zone).putInt("dockIdx", dockIdx).putInt("gridIdx", gridIdx).apply();
  }

  void goHome() { ddOpen = false; int o = key(); if (!dock.isEmpty()) zone = 1; commit(o); }
  void onBack() { if (ddOpen) { ddOpen = false; invalidate(); } else if (zone != 1 && !dock.isEmpty()) { int o = key(); zone = 1; commit(o); } }

  // ---------- teclas ----------
  boolean onKey(int k) {
    if (ddOpen) return ddKey(k);
    if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER || k == KeyEvent.KEYCODE_BUTTON_A) { activate(); return true; }
    boolean L = k == KeyEvent.KEYCODE_DPAD_LEFT, R = k == KeyEvent.KEYCODE_DPAD_RIGHT, U = k == KeyEvent.KEYCODE_DPAD_UP, D = k == KeyEvent.KEYCODE_DPAD_DOWN;
    if (!(L || R || U || D)) return false;
    int old = key(); boolean ch = false; int n = grid.size();
    if (zone == 0) {
      if (L && topIdx > 0) { topIdx--; ch = true; }
      else if (R && topIdx < 2) { topIdx++; ch = true; }
      else if (D) { if (!dock.isEmpty()) { zone = 1; ch = true; } else if (n > 0) { zone = 2; ch = true; } }
    } else if (zone == 1) {
      if (L && dockIdx > 0) { dockIdx--; ch = true; }
      else if (R && dockIdx < dock.size() - 1) { dockIdx++; ch = true; }
      else if (U) { zone = 0; ch = true; }
      else if (D && n > 0) { zone = 2; gridIdx = Math.min(dockIdx, n - 1); ch = true; }
    } else {
      if (L && gridIdx % 4 > 0) { gridIdx--; ch = true; }
      else if (R && gridIdx % 4 < 3 && gridIdx + 1 < n) { gridIdx++; ch = true; }
      else if (U) { if (gridIdx < 4) { zone = 1; dockIdx = Math.min(gridIdx, Math.max(0, dock.size() - 1)); } else gridIdx -= 4; ch = true; }
      else if (D) { if (gridIdx + 4 < n) { gridIdx += 4; ch = true; } else if ((gridIdx / 4 + 1) * 4 < n) { gridIdx = n - 1; ch = true; } }
    }
    if (ch) commit(old);
    return true;
  }

  boolean ddKey(int k) {
    if (k == KeyEvent.KEYCODE_DPAD_DOWN) { if (ddIdx < inputs.size() - 1) ddIdx++; }
    else if (k == KeyEvent.KEYCODE_DPAD_UP) { if (ddIdx > 0) ddIdx--; else ddOpen = false; }
    else if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER || k == KeyEvent.KEYCODE_BUTTON_A) {
      ddOpen = false; start(inputs.get(ddIdx).intent);
    } else ddOpen = false;
    invalidate(); return true;
  }

  void activate() {
    if (zone == 0) {
      if (topIdx == 0) { loadInputs(); ddIdx = 0; ddOpen = true; invalidate(); }
      else if (topIdx == 1) settings(Settings.ACTION_WIFI_SETTINGS);
      else settings(Settings.ACTION_SETTINGS);
    } else {
      App a = cur(); if (a == null) return;
      start(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER).setClassName(a.pkg, a.cls));
    }
  }
  void start(Intent i) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)); } catch (Exception e) { } }
  void settings(String act) {
    try { ctx.startActivity(new Intent(act).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
    catch (Exception e) { start(new Intent().setClassName("com.android.tv.settings", "com.android.tv.settings.MainSettings")); }
  }

  // ---------- desenho ----------
  static int a(int col, int alpha) { return (Math.max(0, Math.min(255, alpha)) << 24) | (col & 0xFFFFFF); }
  void txt(Canvas c, String s, float x, float y, float size, Typeface tf, int col, float ls, Paint.Align al) {
    pText.setTypeface(tf); pText.setTextSize(size); pText.setColor(col); pText.setLetterSpacing(ls); pText.setTextAlign(al);
    c.drawText(s, x, y, pText);
  }

  @Override protected void onDraw(Canvas c) {
    float s = getWidth() / W; c.save(); c.scale(s, s);
    c.drawColor(bg);
    if (wall != null) { c.drawBitmap(wall, null, full, null); c.drawColor(0xA0000000); }
    int gc = curGlow();
    pGlow.setShader(new RadialGradient(960, 560, 1100, new int[]{a(gc, 150), a(gc, 0)}, null, Shader.TileMode.CLAMP));
    c.drawRect(0, 0, W, H, pGlow);

    float sc = curScroll(), ha = Math.max(0, 1 - sc / 260f);
    if (ha > 0) {
      Calendar cal = Calendar.getInstance(); int hr = cal.get(Calendar.HOUR_OF_DAY);
      txt(c, hr < 12 ? "BOM DIA" : hr < 18 ? "BOA TARDE" : "BOA NOITE", 96, 112, 26, tfMed, a(0xFFFFFF, (int) (170 * ha)), 0.25f, Paint.Align.LEFT);
      String clock = String.format(Locale.US, "%02d:%02d", hr, cal.get(Calendar.MINUTE));
      txt(c, clock, 90, 224, 120, tfThin, a(0xFFFFFF, (int) (255 * ha)), 0f, Paint.Align.LEFT);
      float cw = pText.measureText(clock);
      pFill.setColor(a(0xFFFFFF, (int) (80 * ha))); c.drawRect(96 + cw + 28, 160, 98 + cw + 28, 222, pFill);
      String date = new SimpleDateFormat("EEEE, d 'DE' MMMM", new Locale("pt", "BR")).format(new Date()).toUpperCase(new Locale("pt", "BR"));
      txt(c, date, 96 + cw + 56, 214, 26, tfReg, a(0xFFFFFF, (int) (190 * ha)), 0.15f, Paint.Align.LEFT);
    }

    c.save(); c.clipRect(0, 170, W, H); c.translate(0, -sc);
    if (zone <= 1 && !dock.isEmpty()) txt(c, dock.get(dockIdx).label, 96, 524, 78, tfMed, 0xFFFFFFFF, 0f, Paint.Align.LEFT);
    pFill.setColor(0x1CFFFFFF); c.drawRoundRect(96, DOCK_Y - 28, 1824, DOCK_Y + TH + 58, 64, 64, pFill);
    float hl = curHl();
    if (hl > 0.01f) {
      RectF r = curRect();
      pFill.setColor(a(0xFFFFFF, (int) (80 * hl))); pStroke.setColor(a(0xFFFFFF, (int) (150 * hl)));
      c.drawRoundRect(r.left - 24, r.top - 24, r.right + 24, r.bottom + 24, 36, 36, pFill);
      c.drawRoundRect(r.left - 24, r.top - 24, r.right + 24, r.bottom + 24, 36, 36, pStroke);
    }
    int now = key();
    for (int i = 0; i < dock.size(); i++) tileDraw(c, dock.get(i), dockRect(i), 100 + i, now);
    for (int i = 0; i < grid.size(); i++) {
      RectF r = gridRect(i);
      if (r.top - sc > H || r.bottom - sc < 120) continue;
      tileDraw(c, grid.get(i), r, 200 + i, now);
    }
    c.restore();

    // barra superior (fixa)
    String[] lb = {"Entradas", wifi, "Configurações"}; float right = 1824;
    for (int i = 2; i >= 0; i--) {
      pText.setTypeface(tfReg); pText.setTextSize(28); pText.setLetterSpacing(0);
      float w = pText.measureText(lb[i]) + 64; pills[i].set(right - w, 62, right, 126); right -= w + 20;
      boolean f = zone == 0 && topIdx == i;
      pFill.setColor(f ? 0xD8FFFFFF : 0x2EFFFFFF); c.drawRoundRect(pills[i], 32, 32, pFill);
      txt(c, lb[i], pills[i].centerX(), 104, 28, tfReg, f ? 0xFF101015 : 0xE6FFFFFF, 0f, Paint.Align.CENTER);
    }
    if (ddOpen) {
      RectF an = pills[0]; float w = Math.max(an.width(), 340), top = an.bottom + 12, h = 16 + inputs.size() * 64;
      pFill.setColor(0xF0202028); c.drawRoundRect(an.left, top, an.left + w, top + h, 36, 36, pFill);
      for (int i = 0; i < inputs.size(); i++) {
        float y = top + 8 + i * 64; boolean f = i == ddIdx;
        if (f) { pFill.setColor(0xD8FFFFFF); c.drawRoundRect(an.left + 8, y, an.left + w - 8, y + 64, 32, 32, pFill); }
        txt(c, inputs.get(i).label, an.left + w / 2, y + 41, 28, tfReg, f ? 0xFF101015 : 0xE6FFFFFF, 0f, Paint.Align.CENTER);
      }
    }
    c.restore();
  }

  void tileDraw(Canvas c, App a, RectF r, int key, int now) {
    float t = key == now ? p : (key == selPrev ? 1 - p : 0);
    float sc = 1 + 0.08f * t, cx = r.centerX(), cy = r.centerY();
    c.save(); c.translate(cx, cy); c.scale(sc, sc);
    if (a.bmp != null) c.drawBitmap(a.bmp, -TW / 2f, -TH / 2f, pBmp);
    else {
      pFill.setColor(0xFF22252E); c.drawRoundRect(-TW / 2f, -TH / 2f, TW / 2f, TH / 2f, 22, 22, pFill);
      txt(c, a.label, 0, 8, 30, tfReg, 0xCCFFFFFF, 0f, Paint.Align.CENTER);
    }
    c.restore();
    if (t > 0.02f) txt(c, a.label, cx, r.bottom + 50, 30, tfReg, a(0xFFFFFF, (int) (235 * t)), 0.03f, Paint.Align.CENTER);
  }
}
