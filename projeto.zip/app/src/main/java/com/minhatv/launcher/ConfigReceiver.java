package com.minhatv.launcher;
import android.content.*;
public class ConfigReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c, Intent i) {
    SharedPreferences.Editor e = c.getSharedPreferences("cfg", 0).edit();
    if (i.hasExtra("reset")) e.clear();
    if (i.hasExtra("dock")) e.putString("dock", i.getStringExtra("dock"));
    if (i.hasExtra("bg")) e.putString("bg", i.getStringExtra("bg"));
    e.apply();
  }
}
