package com.minhatv.launcher;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
public class MainActivity extends Activity {
  HomeView v;
  @Override protected void onCreate(Bundle b) { super.onCreate(b); v = new HomeView(this); setContentView(v); }
  @Override protected void onResume() { super.onResume(); v.reload(); }
  @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); v.goHome(); }
  @Override public boolean onKeyDown(int k, KeyEvent e) {
    if (k == KeyEvent.KEYCODE_BACK) { v.onBack(); return true; }
    return v.onKey(k) || super.onKeyDown(k, e);
  }
}
