# Launcher estilo Apple TV (MinhaTV)

Tudo é reversível: nada é desinstalado, só desativado com `pm disable-user`.

## Reativar um app
    adb shell pm list packages -d          # lista os desativados
    adb shell pm enable NOME.DO.PACOTE     # reativa um
    bash restaurar.sh                      # reativa tudo e remove o launcher novo

## Trocar a ordem do dock (4 apps, sem recompilar)
    adb shell am broadcast -n com.minhatv.launcher/.ConfigReceiver --es dock "pkg1,pkg2,pkg3,pkg4"
    adb shell am force-stop com.minhatv.launcher
Depois aperte Home. Pacotes atuais: com.global.unitviptv, com.spotify.tv.android, com.google.android.youtube.tv, com.netflix.ninja.

## Papel de parede
Imagem (leve, escurecida automaticamente):
    adb push ~/storage/pictures/foto.jpg /sdcard/Android/data/com.minhatv.launcher/files/wallpaper.jpg
    adb shell am force-stop com.minhatv.launcher
Para remover: `adb shell rm /sdcard/Android/data/com.minhatv.launcher/files/wallpaper.jpg`.
Cor de fundo:
    adb shell am broadcast -n com.minhatv.launcher/.ConfigReceiver --es bg "#101018"
Voltar ao padrão: `--ez reset true`.

## Instalar / atualizar
O APK é compilado no GitHub Actions (aba Releases do seu repositório). Baixe `app-debug.apk` e rode `bash instalar.sh`.
Para atualizar o visual: edite HomeView.java no GitHub, o APK novo sai sozinho.

## Fonte Outfit
O workflow baixa a Outfit durante a compilação. Se o download falhar, o launcher usa a fonte padrão do sistema.
