#!/data/data/com.termux/files/usr/bin/bash
# Desativa o launcher original e as linhas de recomendação. Reversível com restaurar.sh
for p in com.google.android.tvlauncher com.google.android.tvrecommendations; do
  adb shell pm disable-user --user 0 "$p" < /dev/null
  echo "$p" >> "$HOME/storage/shared/tv-backup/lote_launcher.txt"
done
