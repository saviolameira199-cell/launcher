#!/data/data/com.termux/files/usr/bin/bash
# Uso: bash desativar_lote.sh lista.txt   (um pacote por linha). Roda um pm por vez.
while read -r p; do
  [ -n "$p" ] && adb shell pm disable-user --user 0 "$p" < /dev/null
done < "$1"
