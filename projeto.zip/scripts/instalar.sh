#!/data/data/com.termux/files/usr/bin/bash
# Uso: bash instalar.sh [caminho-do-apk]   (padrão: ~/storage/downloads/app-debug.apk)
APK="${1:-$HOME/storage/downloads/app-debug.apk}"
PKG=com.minhatv.launcher
adb devices | grep -q "device$" || { echo "TV não conectada. Rode: adb connect IP:PORTA"; exit 1; }
[ -f "$APK" ] || { echo "APK não encontrado: $APK"; exit 1; }
adb install -r "$APK" || exit 1
adb shell pm grant $PKG android.permission.ACCESS_FINE_LOCATION
adb shell cmd package set-home-activity $PKG/.MainActivity
adb shell am start -a android.intent.action.MAIN -c android.intent.category.HOME
echo "Pronto. Aperte Home na TV (ou use o app Google TV). O launcher antigo AINDA está ativo."
echo "Se ficou bom, rode: bash trocar_launcher.sh"
