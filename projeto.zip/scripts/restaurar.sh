#!/data/data/com.termux/files/usr/bin/bash
# Reativa TUDO que foi desativado (lote*.txt) e remove o launcher novo.
cd "$HOME/storage/shared/tv-backup" || exit 1
for f in lote*.txt; do
  while read -r p; do
    [ -n "$p" ] && adb shell pm enable "$p" < /dev/null
  done < "$f"
done
adb shell pm enable com.google.android.tvlauncher < /dev/null
adb shell pm enable com.google.android.tvrecommendations < /dev/null
adb uninstall com.minhatv.launcher
echo "Restaurado. Aperte Home na TV."
